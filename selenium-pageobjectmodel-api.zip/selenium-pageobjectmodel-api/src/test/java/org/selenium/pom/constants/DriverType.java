package org.selenium.pom.constants;

public enum DriverType {
    CHROME,
    FIREFOX
}
